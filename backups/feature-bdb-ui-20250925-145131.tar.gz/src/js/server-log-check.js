console.log('Checking server logs...')
